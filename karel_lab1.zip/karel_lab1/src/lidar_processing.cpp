#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "std_msgs/Float64.h"

ros::Publisher laserPub;

class LidarProcessor{
  private:
    ros::NodeHandle n;
    ros::Publisher cpPub;
    ros::Publisher fpPub;
    ros::Subscriber laserSub;
    std_msgs::Float64 closest_p;
    std_msgs::Float64 farthest_p;

  public:
    LidarProcessor(){
      cpPub = n.advertise<std_msgs::Float64>("closest_point", 10);
      fpPub = n.advertise<std_msgs::Float64>("farthest_point", 10);

      laserSub = n.subscribe("scan", 10, &LidarProcessor::laserCallback, this);
    }


    void laserCallback(const sensor_msgs::LaserScan::ConstPtr& msg){
      std_msgs::Float64 min;
      std_msgs::Float64 max;

      std::vector<float> laser_data = msg->ranges;

      std::vector<float>::iterator it;
      for(it = laser_data.begin(); it != laser_data.end(); ++it)
      {
        if (std::isinf(*it) || std::isnan(*it))
        {
            laser_data.erase(it);
        }
      }

      std::sort(laser_data.begin(), laser_data.end());

      // std::cout << laser_data.front() << std::endl;
      // std::cout << laser_data.back() << std::endl;

      closest_p.data = laser_data.front();
      farthest_p.data = laser_data.back();

      cpPub.publish(closest_p );
      fpPub.publish(farthest_p );
    }
};

int main(int argc, char **argv)
{

  ros::init(argc,argv,"lidar_processor");
  LidarProcessor lp;

  ros::spin();
  return 0;
}
