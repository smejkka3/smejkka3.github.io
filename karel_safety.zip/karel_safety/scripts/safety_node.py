#!/usr/bin/env python
import rospy

# TODO: import ROS msg types and libraries
from ackermann_msgs.msg import AckermannDriveStamped
from std_msgs.msg import Bool
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import numpy as np
from math import cos


class Safety(object):
    """
    The class that handles emergency braking.
    """
    def __init__(self):
        """
        One publisher should publish to the /brake topic with a AckermannDriveStamped brake message.
        One publisher should publish to the /brake_bool topic with a Bool message.
        You should also subscribe to the /scan topic to get the LaserScan messages and
        the /odom topic to get the current speed of the vehicle.
        The subscribers should use the provided odom_callback and scan_callback as callback methods
        NOTE that the x component of the linear velocity in odom is the speed
        """
        self.speed = 0

        self.TTC_MIN = 0.3
        self.brake = AckermannDriveStamped()
        self.brake_bool = Bool()
        # TODO: create ROS subscribers and publishers.
        self.brake_publisher = rospy.Publisher('/brake', AckermannDriveStamped, queue_size=10)
        self.brake_bool_publisher = rospy.Publisher('/brake_bool', Bool, queue_size=10)

        self.scan_subscriber = rospy.Subscriber('/scan', LaserScan, self.scan_callback)
        self.odom_subscriber = rospy.Subscriber('/odom', Odometry, self.odom_callback)


    def odom_callback(self, odom_msg):
        # TODO: update current speed
        self.speed = odom_msg.twist.twist.linear.x


    def scan_callback(self, scan_msg):
        # TODO: calculate TTC
        range_rate = []
        #iterate trough each laser beam and calculate range_rate for this beam as in the tutorial slides
        for theta_i in np.arange(scan_msg.angle_min,scan_msg.angle_max, scan_msg.angle_increment):
            range_rate_i = self.speed * cos(theta_i)
            #instead of 0 as in tutorial set it close to 0 as it would cause div by 0
            range_rate_i = max(range_rate_i, 0.000001)
            range_rate.append(range_rate_i)
        #div by 0 but it gives inf TTC so doesn't matter
        ranges = np.array(scan_msg.ranges)

        TTC = ranges/range_rate
        # TODO: publish brake message and publish controller bool
        if(min(TTC) < self.TTC_MIN):
            rospy.loginfo("Close to Obstacle, BREAK!")
            self.brake_bool.data = True
            self.brake.drive.speed = 0.
        else:
            self.brake_bool.data = False

        self.brake_publisher.publish(self.brake)
        self.brake_bool_publisher.publish(self.brake_bool)


    # def lidar_processor(self, scan_msg, range_rate):
    #     laser_data = np.array(scan_msg.ranges)[~np.isinf(scan_msg.ranges)]
    #     laser_data_filtered = laser_data[~np.isnan(laser_data)]
    #
    #     return laser_data_filtered


def main():
    rospy.init_node('safety_node')
    sn = Safety()
    rospy.spin()
if __name__ == '__main__':
    main()
