#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/LaserScan.h>
// TODO: include ROS msg type headers and libraries
#include <ackermann_msgs/AckermannDriveStamped.h>
#include <std_msgs/Bool.h>

class Safety {
// The class that handles emergency braking
private:
    ros::NodeHandle n;
    double speed;
    float TTC_MIN = 0.15;

    ackermann_msgs::AckermannDriveStamped brake;
    std_msgs::Bool brake_bool;
    // TODO: create ROS subscribers and publishers
    ros::Publisher brake_publisher;
    ros::Publisher brake_bool_publisher;

    ros::Subscriber scan_subscriber;
    ros::Subscriber odom_subscriber;

    // void lidarProcessor(std::vector<float> &laser_data){
    //     std::vector<float>::iterator it;
    //     for(it = laser_data.begin(); it != laser_data.end(); ++it)
    //     {
    //         if (std::isinf(*it) || std::isnan(*it))
    //         {
    //             laser_data.erase(it);
    //         }
    //     }
    // }
public:
    Safety() {
        n = ros::NodeHandle();
        speed = 0.0;
        /*
        One publisher should publish to the /brake topic with an
        ackermann_msgs/AckermannDriveStamped brake message.
        One publisher should publish to the /brake_bool topic with a
        std_msgs/Bool message.
        You should also subscribe to the /scan topic to get the
        sensor_msgs/LaserScan messages and the /odom topic to get
        the nav_msgs/Odometry messages
        The subscribers should use the provided odom_callback and
        scan_callback as callback methods
        NOTE that the x component of the linear velocity in odom is the speed
        */

        // TODO: create ROS subscribers and publishers
        brake_publisher = n.advertise<ackermann_msgs::AckermannDriveStamped>("brake", 10);
        brake_bool_publisher = n.advertise<std_msgs::Bool>("brake_bool", 10);

        scan_subscriber = n.subscribe("scan", 10, &Safety::scan_callback, this);
        odom_subscriber = n.subscribe("odom", 10, &Safety::odom_callback, this);
    }
    void odom_callback(const nav_msgs::Odometry::ConstPtr &odom_msg) {
        // TODO: update current speed
        speed = odom_msg->twist.twist.linear.x;
    }

    void scan_callback(const sensor_msgs::LaserScan::ConstPtr &scan_msg) {
        // TODO: calculate TTC
        std::vector<float>laser_data = scan_msg->ranges;

        int laser_beam_i;
        float theta_i;
        float range_rate_i;

        std::vector<float>::iterator it;
        std::vector<float> TTC(laser_data.size(), 0);

        // go trough the scan data and calculate angles
        for(it = laser_data.begin(); it != laser_data.end(); ++it)
        {
            laser_beam_i = it - laser_data.begin();
            theta_i = (scan_msg->angle_min) + (scan_msg->angle_increment * laser_beam_i);
            range_rate_i = speed * cos(theta_i);
            // ROS_INFO("range_rate_i: %f", range_rate_i);
            range_rate_i = std::max(range_rate_i, float(0.000001));


            TTC[laser_beam_i] = ((*it)/range_rate_i);
        }
        // lidarProcessor(TTC);
        std::sort (TTC.begin(), TTC.end());

        if(TTC.front() < TTC_MIN){
            // ROS_INFO("min_TTC: %f",TTC.front());
            // ROS_INFO("TTC_MIN: %f",TTC_MIN);
            // ROS_INFO("speed: %f",speed);
            brake.drive.speed = 0.0;
            brake_bool.data = true;
        }else{
            brake_bool.data = false;
        }
        // TODO: publish drive/brake message
        brake_publisher.publish(brake);
        brake_bool_publisher.publish(brake_bool);
    }

};
int main(int argc, char ** argv) {
    ros::init(argc, argv, "safety_node");
    Safety sn;
    ros::spin();
    return 0;
}
