#!/usr/bin/env python
import rospy
from nav_msgs.msg import Odometry
from ackermann_msgs.msg import AckermannDriveStamped
import numpy as np
import tf
import pandas as pd
import rospkg
import os
from waypoints_visualizer import GoalVisualizer

rospack = rospkg.RosPack()
package_path = rospack.get_path('karel_pure_pursuit')
abs_path = os.path.sep.join([package_path,'logs','wp-2020-11-22-16-48-36.csv'])
waypoints = pd.read_csv(abs_path,header=None)
#remove overlapping points
waypoints = waypoints.round(1)
waypoints.drop_duplicates([0, 1], inplace= True)
waypoints = waypoints.to_numpy()

class PurePursuit(object):
    """
    The class that handles pure pursuit.
    """
    def __init__(self):
        self.LOOKAHEAD = 1.2
        self.goal_points = waypoints[0]
        self.vis_goal = GoalVisualizer()
        # TODO: create ROS subscribers and publishers.
        odom_topic = '/odom'
        drive_topic = '/nav'
 
        self.pose_sub = rospy.Subscriber(odom_topic, Odometry, self.pose_callback)
        self.drive_pub = rospy.Publisher( drive_topic, AckermannDriveStamped, queue_size = 1 )
        

    def pose_callback(self, pose_msg):
        # TODO: find the current waypoint to track using methods mentioned in lecture
        pos = np.array([pose_msg.pose.pose.position.x,
                        pose_msg.pose.pose.position.y])
               
        quaternion = np.array([
                        pose_msg.pose.pose.orientation.x, 
                        pose_msg.pose.pose.orientation.y,
                        pose_msg.pose.pose.orientation.z,
                        pose_msg.pose.pose.orientation.w])
        
        euler = tf.transformations.euler_from_quaternion(quaternion)
        yaw = euler[2]

        waypoint_distance = np.linalg.norm((waypoints[:, 0:2] - pos), axis=1)
        waypoint_idx = np.where(abs( waypoint_distance - self.LOOKAHEAD ) < 0.3)[0]

        # TODO: transform goal point to vehicle frame of reference
        goal_points_lst = []
        for idx in waypoint_idx:
            d_x = waypoints[idx,0] - pos[0]
            d_y = waypoints[idx,1] - pos[1]

            x = np.cos(yaw)*d_x + np.sin(yaw)*d_y
            y = -np.sin(yaw)*d_x + np.cos(yaw)*d_y

            #check if the point id in front of the car
            if abs(np.arctan2(y,x)) <  np.pi/2:
                goal_points_lst.append(waypoints[idx][0:2])

        #get point in the max LOOKAHEAD distance 
        goal_point_idx = np.argmax(np.linalg.norm(goal_points_lst - pos,axis=1) - self.LOOKAHEAD)
        self.goal_point = goal_points_lst[goal_point_idx]
        
        d_x = self.goal_point[0] - pos[0]
        d_y = self.goal_point[1] - pos[1]

        self.vis_goal.visualize_goal(self.goal_point[0],self.goal_point[1])
        x = np.cos(yaw)*d_x + np.sin(yaw)*d_y
        y = -np.sin(yaw)*d_x + np.cos(yaw)*d_y  
        # TODO: calculate curvature/steering angle
        L = np.hypot(x,y) #Pythagorean theroem

        angle = 2*y/(L**2)

        #Set speed based on the angle the car is currenly going
        if abs(angle) <= np.degrees(10):
            velocity  = 5.5
        elif abs(angle) <= np.degrees(20):
            velocity = 3.5
        else:
            velocity = 1.5
 
        # TODO: publish drive message, don't forget to limit the steering angle between -0.4189 and 0.4189 radians
        drive_msg = AckermannDriveStamped()
        drive_msg.header.stamp = rospy.Time.now()
        drive_msg.header.frame_id = "nav"
        drive_msg.drive.steering_angle = np.clip(angle, -0.4189, 0.4189)
        drive_msg.drive.speed = velocity 
        self.drive_pub.publish(drive_msg)

def main():
    rospy.init_node('pure_pursuit_node')
    pp = PurePursuit()
    rospy.spin()
if __name__ == '__main__':
    main()
