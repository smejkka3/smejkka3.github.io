#!/usr/bin/env python
import rospy
import numpy as np
import os
import pandas as pd
import rospkg
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray

class WaypointsVisualizer(object):
    """
    Class to handle pure_pursuit visualization of waypoints
    """
    def __init__(self):
        vis_topic = 'visualization_marker_array'
        self.vis_pub = rospy.Publisher(vis_topic, MarkerArray, queue_size = 1)

        rospack = rospkg.RosPack()
        package_path = rospack.get_path('karel_pure_pursuit')
        abs_path = os.path.sep.join([package_path,'logs','wp-2020-11-22-16-48-36.csv'])

        self.waypoints = self.load_log_file(abs_path)
        
        self.create_visualization(self.waypoints)

    
    def load_log_file(self, abs_path):
        df = pd.read_csv(abs_path,header=None)
        df.drop([2,3], axis=1, inplace= True)
        df = df.round(1)
        df.drop_duplicates([0, 1], inplace= True)

        return df.to_numpy()

    def create_visualization(self, waypoints):
        while not rospy.is_shutdown():
            markerArray = MarkerArray()
 
            for i in range(len(waypoints)):
                marker = Marker()
                point = waypoints[i,:]
                marker.pose.position.x = point[0]
                marker.pose.position.y = point[1]
                marker.pose.position.z = 0
                marker.id = i

                markerArray.markers.append(marker)

            for marker in markerArray.markers:
                marker.header.frame_id = "map"
                marker.type = marker.SPHERE
                marker.action = marker.ADD
                marker.scale.x = 0.1
                marker.scale.y = 0.1
                marker.scale.z = 0.1
                marker.color.a = 1.0
                marker.color.r = 0.0
                marker.color.g = 1.0
                marker.color.b = 0.1
                marker.pose.orientation.x = 0.0
                marker.pose.orientation.y = 0.0
                marker.pose.orientation.z = 0.0
                marker.pose.orientation.w = 1.0


            
            self.vis_pub.publish(markerArray)
            rospy.sleep(0.1)
        
def main():
    rospy.init_node('waypoints_visualization_node')
    rospy.loginfo("Visualizing waypoints...")
    wv = WaypointsVisualizer()

if __name__ == '__main__':
    main()


class GoalVisualizer(object):
    """
    Class to handle pure_pursuit visualization of waypoints
    """
    def __init__(self):
        self.goal_pub = rospy.Publisher('/goal_waypoint', MarkerArray, queue_size = 1)

    def visualize_goal(self,x, y):
        # create a marker array
        markerArray = MarkerArray()

        marker = Marker()
        marker.header.frame_id = '/map'
        marker.type = marker.SPHERE
        marker.action = marker.ADD
        marker.scale.x = 0.3
        marker.scale.y = 0.3
        marker.scale.z = 0.2
        marker.color.a = 1.0
        marker.color.r = 1.0
        marker.color.g = 0.2
        marker.color.b = 0.0
        marker.pose.orientation.w = 1.0
        marker.pose.position.x = x
        marker.pose.position.y = y
        marker.pose.position.z = 0
        markerArray.markers.append(marker)
        
        self.goal_pub.publish(markerArray)
