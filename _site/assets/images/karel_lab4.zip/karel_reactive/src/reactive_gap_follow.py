#!/usr/bin/env python
from __future__ import print_function
import sys
import math
import numpy as np

#ROS Imports
import rospy
from sensor_msgs.msg import Image, LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive

ANGLE_RANGE = 90 # look only 45 degress left and right https://linklab-uva.github.io/autonomousracing/assets/files/ftg.pdf
CAR_LENGTH = 0.50 # Traxxas Rally is 20 inches or 0.5 meters
LOOK_AHEAD_DISTANCE = 3

class reactive_follow_gap:
    def __init__(self):
        #Topics & Subscriptions,Publishers
        lidarscan_topic = '/scan'
        drive_topic = '/nav'

        self.lidar_sub = rospy.Subscriber( lidarscan_topic, LaserScan, self.lidar_callback)
        self.drive_pub = rospy.Publisher( drive_topic, AckermannDriveStamped, queue_size = 1)

    def zero_closest_obstacle(self, ranges, angles, idx_closest_p):
        radius = CAR_LENGTH/2
        cp = ranges[idx_closest_p]
        #print(math.degrees(angles[idx_closest_p]))
        # get the angle of bubble with radius
        if cp >= radius:
            theta = np.arcsin(radius/cp)
        elif cp < radius:
            theta = np.arcsin(math.radians(90))

        # get the angle range
        min_angle = angles[idx_closest_p] - theta
        max_angle = angles[idx_closest_p] + theta

        #set ranges in the bubble to 0
        ranges[(angles > min_angle) & (max_angle >= angles)] = 0.

        return ranges

    def running_mean(self, ranges, windowLen = 7):
        return np.convolve(ranges, np.ones((windowLen,))/windowLen, mode='same')


    def preprocess_lidar(self, ranges, angle_min, angle_max):
        """ Preprocess the LiDAR scan array. Expert implementation includes:
                Starting with getting valid ranges as in previous assignment
                 -> reference TU Dortmund Racing car
                        https://github.com/Autonomous-Racing-PG/ar-tu-do/blob/master/ros_ws/src/autonomous/wallfollowing2/script/wallfollowing.py
                        get_scan_as_cartesian() method

            1.Setting each value to the mean over some window
            2.Rejecting high values (eg. > 3m)
        """
        angles = np.linspace(angle_min, angle_max, ranges.shape[0])

        laser_range = angle_max - angle_min

        #use only valid scans
        if math.radians(ANGLE_RANGE) < laser_range:
            skip_left = int((-angle_min - math.radians(ANGLE_RANGE) / 2) / laser_range * ranges.shape[0])
            skip_right = int((angle_max - math.radians(ANGLE_RANGE) / 2) / laser_range * ranges.shape[0])
            angles = angles[skip_left:-1 - skip_right]
            ranges = ranges[skip_left:-1 - skip_right]

        inf_nan_mask = np.logical_or(np.isinf(ranges),np.isnan(ranges))
        if inf_nan_mask.any():
            ranges = ranges[~inf_nan_mask]
            angles = angles[~inf_nan_mask]

        # Step 1.
        ranges_rm = self.running_mean(ranges)

        # Step 2.
        proc_ranges = np.clip(ranges_rm, None, LOOK_AHEAD_DISTANCE)

        return proc_ranges, angles

    def find_max_gap(self, free_space_ranges):
        """ Return the start index & end index of the max gap in free_space_ranges
        """
        # get he nonzero elements and split it, than get the longest range and it first and last idx
        free_space_ranges_idx = np.flatnonzero(free_space_ranges)
        seq = max(np.split(free_space_ranges_idx, np.where(np.diff(free_space_ranges_idx) != 1)[0]+1), key=len)
        start_idx = seq[0]
        end_idx = seq[-1]

        return start_idx, end_idx

    def find_best_point(self, start_i, end_i, ranges):
        """Start_i & end_i are start and end indicies of max-gap range, respectively
        Return best point in ranges
	Naive: Choose the furthest point within ranges and go there
        """
        # get middle index of of farthest points
        best_idx = int(np.mean(np.where(ranges == max(ranges[start_i:end_i]))[0]))

        return best_idx

    def lidar_callback(self, data):
        """ Process each LiDAR scan as per the Follow Gap algorithm & publish an AckermannDriveStamped Message
        """
        ranges = np.array(data.ranges)
        proc_ranges, proc_angles = self.preprocess_lidar(ranges, data.angle_min, data.angle_max)

        #Find closest point to LiDAR
        cp_idx = np.argmin(proc_ranges)
        #Eliminate all points inside 'bubble' (set them to zero)
        proc_ranges = self.zero_closest_obstacle(proc_ranges, proc_angles, cp_idx)
        #Find max length gap
        start_idx, end_idx = self.find_max_gap(proc_ranges)
        #Find the best point in the gap
        best_idx = self.find_best_point(start_idx, end_idx, proc_ranges)
        best_angle = proc_angles[best_idx]
        best_range = proc_ranges[best_idx]

        if 0 <  abs(best_angle) <= math.radians(10):
            speed = 3.5
        elif math.radians(10) < abs(best_angle) < math.radians(20):
            speed = 2
        else:
            speed = 1

        #Publish Drive message
        drive_msg = AckermannDriveStamped()
        drive_msg.header.stamp = rospy.Time.now()
        drive_msg.header.frame_id = "laser"
        drive_msg.drive.steering_angle = best_angle
        drive_msg.drive.speed = speed
        self.drive_pub.publish(drive_msg)


def main(args):
    rospy.init_node("FollowGap_node", anonymous=True)
    rfgs = reactive_follow_gap()
    rospy.sleep(0.1)
    rospy.spin()

if __name__ == '__main__':
    main(sys.argv)
