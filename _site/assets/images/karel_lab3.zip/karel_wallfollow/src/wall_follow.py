#!/usr/bin/env python
from __future__ import print_function
import sys
import math
import numpy as np

#ROS Imports
import rospy
from sensor_msgs.msg import Image, LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive

#PID CONTROL PARAMS
# only params that's working for me
kp = 2 #the lower the less responsive to the error magitude
kd = 0.02 #increase to quicker reaction to the increasing error
ki = 0. # increase - more sensitive to error
servo_offset = 0.0
prev_error = 0.0
error = 0.0
integral = 0.0

#WALL FOLLOW PARAMS
ANGLE_RANGE = 270 # Hokuyo 10LX has 270 degrees scan
DESIRED_DISTANCE_RIGHT = 0.9 # meters
DESIRED_DISTANCE_LEFT = 0.85 # when i put the car closer I start to hit the last fake turn in the map, can't tune the params to make it work otherwise
VELOCITY = 2.00 # meters per second
CAR_LENGTH = 0.50 # Traxxas Rally is 20 inches or 0.5 meters

class WallFollow:
    """ Implement Wall Following on the car
    """
    def __init__(self):
        #Topics & Subs, Pubs
        lidarscan_topic = '/scan'
        drive_topic = '/nav'

        self.lidar_sub = rospy.Subscriber( lidarscan_topic, LaserScan, self.lidar_callback)
        self.drive_pub = rospy.Publisher( drive_topic, AckermannDriveStamped, queue_size = 1)

    def preprocess_scan(self, data):
        """
        reference TU Dortmund Racing car
        https://github.com/Autonomous-Racing-PG/ar-tu-do/blob/master/ros_ws/src/autonomous/wallfollowing2/script/wallfollowing.py
        get_scan_as_cartesian() method
        """
        ranges = np.array(data.ranges)
        angles = np.linspace(data.angle_min, data.angle_max, ranges.shape[0])

        laser_range = data.angle_max - data.angle_min

        if math.radians(ANGLE_RANGE) < laser_range:
            skip_left = int((-data.angle_min - math.radians(ANGLE_RANGE) / 2) / laser_range * ranges.shape[0])
            skip_right = int((data.angle_max - math.radians(ANGLE_RANGE) / 2) / laser_range * ranges.shape[0])
            angles = angles[skip_left:-1 - skip_right]
            ranges = ranges[skip_left:-1 - skip_right]
        #print(ranges.shape[0])
        inf_nan_mask = np.logical_or(np.isinf(ranges),np.isnan(ranges))
        if inf_nan_mask.any():
            ranges = ranges[~inf_nan_mask]
            angles = angles[~inf_nan_mask]

        return ranges, angles

    def getRange(self, data, angle):
        # data: single message from topic /scan
        # angle: between -45 to 225 degrees, where 0 degrees is directly to the right
        # Outputs length in meters to object with angle in lidar scan field of view
        #make sure to take care of nans etc.
        #TODO: implement
        ranges, angles = self.preprocess_scan(data)
        laser_range = max(angles) - min(angles)
        angle_increment = laser_range / ranges.shape[0]

        idx = int((math.radians(angle) - min(angles)) / angle_increment) #TODO fix to use only ranges to get the valid idx
        dist = ranges[idx]

        return dist

    def pid_control(self, error, velocity):
        global integral
        global prev_error
        global kp
        global ki
        global kd

        #TODO: Use kp, ki & kd to implement a PID controller for
        angle = - ( kp * error + ki * ( error + integral ) + kd * ( error - prev_error ) )
        prev_error = error
        #print( math.degrees(angle))
        #as described in the assignment
        if(0 < abs(angle) <= 10):
            velocity = 1.5
        elif(10 < abs(angle) <= 20 ):
            velocity = 1.
        else:
            velocity = 0.5

        drive_msg = AckermannDriveStamped()
        drive_msg.header.stamp = rospy.Time.now()
        drive_msg.header.frame_id = "laser"
        drive_msg.drive.steering_angle = angle
        drive_msg.drive.speed = velocity
        self.drive_pub.publish(drive_msg)

    def followLeft(self, data, a, b, theta):
        #Follow left wall as per the algorithm
        #TODO:implement
        radian = math.radians(theta)
        alpha = math.atan((a * math.cos(radian) - b) / (a * math.sin(radian)))
        AB = b * math.cos(alpha)

        AC = CAR_LENGTH/2 + 0.1 #project car forward - assuming that the lidar is in the middle of the car
        CD = AB + AC*math.sin(alpha)

        error = DESIRED_DISTANCE_LEFT - CD
        return error

    def lidar_callback(self, data):
        """
        Step 1. Obtain two laser scans (distances) a and b, with b taken at 0 degrees and a at an angle theta (0 < theta =< 70)
        Step 2. Use the distances a and b to calculate the angle alpha between the car's x- axis and the left wall and use alpha to find the current distance D_t to the car,
        Step 3. And than alpha and D_t to find the estimated future distance D_t1 to the wall
        Step 4. Run D_t1 trough the PID algorithm described above ( in assignment) to get a steering angle
        """
        # step 1.
        theta = 45
        a = self.getRange(data, theta)
        b = self.getRange(data, 0)
        # step 2 & 3
        error = self.followLeft(data, a, b, theta)

        # step 4 send error to pid_control
        self.pid_control(error, VELOCITY)

def main(args):
    rospy.init_node("WallFollow_node", anonymous=True)
    wf = WallFollow()
    rospy.sleep(0.1)
    rospy.spin()

if __name__=='__main__':
	main(sys.argv)
