#! /usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan
import numpy as np
from std_msgs.msg import Float64, Header
from karel_lab1.msg import scan_range

class LidarProcessor():
    # init 2 publishers (closest and furtherst) and subscriber to scan topic to process it
    def __init__(self):
        self.cpPub = rospy.Publisher("/closest_point", Float64, queue_size=10)
        self.fpPub = rospy.Publisher("/farthest_point", Float64, queue_size=10)
        self.srPub = rospy.Publisher("/scan_range", scan_range, queue_size=10)
        self.laserSub = rospy.Subscriber("/scan", LaserScan, self.laserCallback)

    def laserCallback(self, msg):
        # filer out nans and infs
        laser_data = np.array(msg.ranges)[~np.isinf(msg.ranges)]
        laser_data = laser_data[~np.isnan(laser_data)]

        #create header for the message
        h = Header()
        h.stamp = rospy.Time.now()

        #publish into closest and farthest point publisher as Float64 as well as to scan_range
        self.cpPub.publish(min(laser_data))
        self.fpPub.publish(max(laser_data))
        self.srPub.publish(h,min(laser_data),max(laser_data))
        rate = rospy.Rate(1)

if __name__ == '__main__':
    try:
        rospy.init_node("lidar_processor")
        lp = LidarProcessor()
        rospy.spin()
    except rospy.ROSInterruptException: pass
